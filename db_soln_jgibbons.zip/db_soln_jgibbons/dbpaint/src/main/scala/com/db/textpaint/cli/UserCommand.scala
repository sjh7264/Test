package com.db.textpaint.cli

class UserCommand(val command:String, val description:String, val noParams:Int)
case object CreateCanvas extends UserCommand("C", "C w h Create a new canvas of width w and height h", 2)
case object DrawLine extends UserCommand("L", "L x1 y1 x2 y2 Draw a new line from coordinates  to horizontally or vertically.",4)
case object DrawRect extends UserCommand("R", "R x1 y1 x2 y2 Draw a new rectangle, with upper left corner at coordinate (x1,y1) and lower right coordinate at (x2,y2).", 4)
case object Quit extends UserCommand("Q", "Q Quit the program",0)


