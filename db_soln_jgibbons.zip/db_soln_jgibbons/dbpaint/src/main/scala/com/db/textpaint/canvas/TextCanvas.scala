package com.db.textpaint.canvas

/**
  * Created by Jonathan during 2018.
  *
  * Note that the coordinate system is 1,1 based not 0,0 based
  */
case class TextCanvas(rows:Int, cols:Int) {
  private val pixels = Array.ofDim[Byte](rows, cols)

  def render() :String = {
    "-"*(cols+1) + "\n"+
    pixels.map{s"|"+ _.map{p:Byte=> if (p!=0) "x" else " "}.mkString("")+"|" }.mkString("\n") + "\n"+
      "-"*(cols+1) + "\n"
  }

  def setPixel(x:Int, y:Int) : Unit= {
    boundsCheck(x,y)
    // clients use a 1,1 based coordinate system
    pixels(y-1)(x-1)=1
  }

  def drawLine(x1:Int, y1:Int, x2:Int, y2:Int): Unit = {
    boundsCheck(x1, y1)
    boundsCheck(x2, y2)

    if (x1 == x2) drawVerticalLine(x1, y1, y2)
    if (y1 == y2) drawHorizontalLine(x1, x2, y1)
    else {
      if (x1 < x2) drawDiagonalWithOrderedParams(x1, y1, x2, y2)
      else drawDiagonalWithOrderedParams(x2, y2, x1, y1)
    }
  }

  def drawRect(x1:Int, y1:Int, x2:Int, y2:Int): Unit = {
    boundsCheck(x1, y1)
    boundsCheck(x2, y2)
    drawVerticalLine(x1,y1,y2)
    drawVerticalLine(x2,y1,y2)
    drawHorizontalLine(x1, x2, y1)
    drawHorizontalLine(x1, x2, y2)
  }

  private def drawVerticalLine(x:Int, y1:Int, y2:Int): Unit = {
    val (yy1, yy2) = if (y1<y2) (y1,y2) else (y2,y1)
    for (y<-yy1 to yy2) setPixel(x,y)
  }
  private def drawHorizontalLine(x1:Int,x2:Int, y:Int): Unit = {
    val (xx1, xx2) = if (x1<x2) (x1,x2) else (x2,x1)
    for (x<-xx1 to xx2) setPixel(x,y)
  }

  /**
    * Params are ordered with leftmost point first
    */
  private def drawDiagonalWithOrderedParams(x1:Int, y1:Int, x2:Int, y2:Int): Unit = {
    val incy:Double = (x2-x1)/(y2-y1)
    var y:Double = y1
    for (x <- x1 to x2) {
      setPixel(x,y.toInt)
      y+= incy
    }
  }

  private def boundsCheck(x:Int, y:Int): Unit = {boundsCheckX(x);boundsCheckY(y)}
  private def boundsCheckY(y:Int): Unit = require( y>=1 && y<=rows, s"The y argument is out of bounds, was [$y] expect 1-${rows}")
  private def boundsCheckX(x:Int): Unit = require( x>=1 && x<=cols , s"The x argument is out of bounds, was [$x] expect 1-${cols}")
}
