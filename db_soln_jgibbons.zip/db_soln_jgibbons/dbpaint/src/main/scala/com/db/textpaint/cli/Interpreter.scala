package com.db.textpaint.cli

/**
  * Created by Jonathan during 2018.
  */
case class Interpreter(allCommands:List[UserCommand]) {
  private val commandLookup = allCommands.map{defn=>(defn.command,defn)}.toMap

  def usageStr:String = {
    allCommands.map{c=>s"  ${c.description}"}.mkString("\n")
  }

  /**
    * Public API has no exceptions for normal parsing - ie bad user input.
    */
  def interpret(command:String) : Option[(UserCommand, Array[Int])] = {
    try {
      interpretUsingExceptions(command)
    } catch {
      case ex: IllegalArgumentException => None
      case ex: NumberFormatException => None
    }
  }

  private def interpretUsingExceptions(command:String): Option[(UserCommand, Array[Int])] = {
    require(command.length>0, "Bad command")
    val commands = command.split(" ")

    commandLookup.get(commands(0)) match {
      case Some(command) =>
        require(commands.size==command.noParams+1)
        if (command.noParams>0) {
          val intParams = commands.tail.map(_.toInt)
          Some(command, intParams)
        } else {
          Some(command, Array.empty[Int])
        }
      case _ => None
    }
  }
}
