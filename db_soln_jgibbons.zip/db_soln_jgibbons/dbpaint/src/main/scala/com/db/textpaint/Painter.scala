package com.db.textpaint

import com.db.textpaint.cli.StdinUserInput

/**
  * Created by Jonathan during 2018.
  */
object Painter extends App {
  val tp = new TextPainter(new StdinUserInput())
  tp.start()
}
