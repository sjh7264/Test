package com.db.textpaint.cli

/**
  * Created by Jonathan during 2018.
  */
trait UserInput {
  def getNextCommand() : String
  def display(op:String) : Unit
}

class StdinUserInput extends UserInput {
  def getNextCommand() : String = {
    print("enter command: ")
    scala.io.StdIn.readLine().trim()
  }
  def display(op:String): Unit = println(op)
}
