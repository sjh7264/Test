package com.db.textpaint

import com.db.textpaint.canvas.TextCanvas
import com.db.textpaint.cli._

import scala.annotation.tailrec

/**
  * Created by Jonathan during 2018.
  */
class TextPainter(ui:UserInput) {
  val interpreter = Interpreter(List(CreateCanvas, DrawLine, DrawRect, Quit))
  var canvas:Option[TextCanvas] = None

  def start():Unit = {
    //showUsage()
    loopUntilQuit()
  }

  @tailrec
  private def loopUntilQuit(): Unit = {
    val command = ui.getNextCommand()
    val quit = interpreter.interpret(command) match {
      case Some( (cmd, params) ) =>
        handleCommand(cmd, params)
      case None => false
    }
    if (!quit) {
      canvas.map(_.render()).foreach(s=>ui.display(s))
      loopUntilQuit()
    }
  }

  /**
    * @return true if should quit, true if ask for another command
    */
  private def handleCommand(command:UserCommand, args: Array[Int]) : Boolean = {
    try {
      command match {
        case CreateCanvas =>
          createCanvas(args(0), args(1))
          false
        case DrawLine =>
          drawLine(args(0), args(1), args(2), args(3))
          false
        case DrawRect =>
          drawRect(args(0), args(1), args(2), args(3))
          false
        case Quit => true
      }
    } catch {
      case ex:Exception =>
        ui.display("Bad command, please try again")
        false
    }
  }

  private def createCanvas(w:Int, h:Int): Unit = canvas = Some(TextCanvas(h, w))
  private def drawLine(x1:Int, y1:Int, x2:Int, y2:Int): Unit = canvas.foreach(_.drawLine(x1, y1, x2, y2))
  private def drawRect(x1:Int, y1:Int, x2:Int, y2:Int): Unit = canvas.foreach(_.drawRect(x1, y1, x2, y2))


  def showUsage():Unit = {
    ui.display(
      s"""Usage Painter
         |${interpreter.usageStr}
         |""".stripMargin)
  }

}
