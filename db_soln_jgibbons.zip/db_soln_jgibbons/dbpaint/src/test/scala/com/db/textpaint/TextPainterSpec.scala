package com.db.textpaint

import com.db.textpaint.cli.UserInput
import org.scalatest.FlatSpec

/**
  * Created by Jonathan during 2018.
  */
class TextPainterSpec extends FlatSpec {
  behavior of "TextPainter"

  it should "mimic the spec exactly - test everything" in {
    val expected =
      """enter command: C 20 5
        |---------------------
        ||                    |
        ||                    |
        ||                    |
        ||                    |
        ||                    |
        |---------------------
        |enter command: L 1 3 7 3
        |---------------------
        ||                    |
        ||                    |
        ||xxxxxxx             |
        ||                    |
        ||                    |
        |---------------------
        |enter command: L 7 1 7 3
        |---------------------
        ||      x             |
        ||      x             |
        ||xxxxxxx             |
        ||                    |
        ||                    |
        |---------------------
        |enter command: R 15 2 20 5
        |---------------------
        ||      x             |
        ||      x       xxxxxx|
        ||xxxxxxx       x    x|
        ||              x    x|
        ||              xxxxxx|
        |---------------------
        |enter command: Q
        |""".stripMargin.replace("\r\n", "\n")

    val stub = new UiStub()
    val tp = new TextPainter(stub)
    tp.start()

    println(stub.opStr.toString)

    assert(expected == stub.opStr.toString)
  }

  class UiStub extends UserInput {
    var cmdCnt=0
    val cmds = List("C 20 5", "L 1 3 7 3", "L 7 1 7 3","R 15 2 20 5", "Q")

    val opStr= new StringBuffer("")
    override def getNextCommand(): String = {
      cmdCnt+=1
      val ret = cmds(cmdCnt-1)
      opStr.append(s"enter command: $ret\n")
      ret
    }

    override def display(op: String): Unit = {
      opStr.append(op)
    }
  }
}
