package com.db.textpaint.cli

import org.scalatest.FlatSpec

/**
  * Created by Jonathan during 2018.
  */
class InterpreterSpec extends FlatSpec {
  behavior of "Interpreter"
  val interpreter = Interpreter(List(CreateCanvas, DrawLine, DrawRect, Quit))

  it should "Interpret Canvas correctly" in {
    interpreter.interpret("C 2 8") match {
      case Some( (CreateCanvas, Array(2, 8)) ) =>
      case _ => fail("Expected CreateCanvas")
    }
  }
  it should "Interpret DrawLine correctly" in {
    interpreter.interpret("L 2 3 4 5") match {
      case Some( (DrawLine, Array(2, 3, 4, 5)) ) =>
      case _ => fail("Expected DrawLine")
    }
  }
  it should "Interpret DrawRect correctly" in {
    interpreter.interpret("R 2 3 4 5") match {
      case Some( (DrawRect, Array(2, 3, 4, 5)) ) =>
      case _ => fail("Expected DrawRect")
    }
  }
  it should "Interpret Quit correctly" in {
    interpreter.interpret("Q") match {
      case Some( (Quit, _ ) ) =>
      case _ => fail("Expected Quit")
    }
  }
  it should "Fail a bad command" in {
    interpreter.interpret("Foo") match {
      case None=>
      case Some(bar)=>fail("Expected None")
    }
  }
  it should "Fail a bad parameters" in {
    interpreter.interpret("R 1 2 3 d") match {
      case None=>
      case Some(bar)=>fail("Expected None")
    }
  }
  it should "Fail missing parameters" in {
    interpreter.interpret("R") match {
      case None=>
      case Some(bar)=>fail("Expected None")
    }
  }

  it should "render a usage str" in {
    val expected =
      """  C w h Create a new canvas of width w and height h
        |  L x1 y1 x2 y2 Draw a new line from coordinates  to horizontally or vertically.
        |  R x1 y1 x2 y2 Draw a new rectangle, with upper left corner at coordinate (x1,y1) and lower right coordinate at (x2,y2).
        |  Q Quit the program""".stripMargin.replace("\r\n", "\n")
    assert(expected == interpreter.usageStr)
  }
}
