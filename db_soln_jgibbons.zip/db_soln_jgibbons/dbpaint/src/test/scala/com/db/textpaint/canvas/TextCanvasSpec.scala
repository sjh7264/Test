package com.db.textpaint.canvas

import org.scalatest.FlatSpec

/**
  * Created by Jonathan during 2018.
  */
class TextCanvasSpec extends FlatSpec {
  behavior of "TextCanvas"

  it should "Create a canvas and render it" in {
    val expected =
      """---------------------
       ||                    |
       ||                    |
       ||                    |
       ||                    |
       ||                    |
       |---------------------
       |""".stripMargin.replace("\r\n","\n")

    val c = TextCanvas(5, 20)
    assert(expected==c.render())
  }

  it should "Allow setting a pixel" in {
    val expected =
      """--
        ||x|
        |--
        |""".stripMargin.replace("\r\n","\n")


    val c = TextCanvas(1,1)
    c.setPixel(1,1)
    assert(expected==c.render())
  }
  it should "Bounds check the x" in {
    try {
      val c = TextCanvas(10,10)
      c.setPixel(-1,1)
      fail("Expected exception")
    } catch {
      case ex: IllegalArgumentException if ex.getMessage == "requirement failed: The x argument is out of bounds, was [-1] expect 1-10" =>
      case ex: Exception => fail(s"Expected IllegalArgumentException, got ${ex.getClass}:${ex.getMessage}")
    }
    try {
      val c = TextCanvas(10,10)
      c.setPixel(11,1)
      fail("Expected exception")
    } catch {
      case ex:IllegalArgumentException if ex.getMessage == "requirement failed: The x argument is out of bounds, was [11] expect 1-10" =>
      case ex:Exception => fail(s"Expected IllegalArgumentException, got ${ex.getClass}:${ex.getMessage}")
    }
  }
  it should "Bounds check the Y" in {
    try {
      val c = TextCanvas(10,10)
      c.setPixel(1, -1)
      fail("Expected exception")
    } catch {
      case ex: IllegalArgumentException if ex.getMessage == "requirement failed: The y argument is out of bounds, was [-1] expect 1-10" =>
      case ex: Exception => fail(s"Expected IllegalArgumentException, got ${ex.getClass}:${ex.getMessage}")
    }
    try {
      val c = TextCanvas(10,10)
      c.setPixel(1, 11)
      fail("Expected exception")
    } catch {
      case ex:IllegalArgumentException if ex.getMessage == "requirement failed: The y argument is out of bounds, was [11] expect 1-10" =>
      case ex:Exception => fail(s"Expected IllegalArgumentException, got ${ex.getClass}:${ex.getMessage}")
    }
  }

  it should "Draw a line horizontally" in {
    val expected =
      """---------------------
        ||                    |
        ||                    |
        ||xxxxxxx             |
        ||                    |
        ||                    |
        |---------------------
        |""".stripMargin.replace("\r\n","\n")
    val c = TextCanvas(5,20)
    c.drawLine(1,3,7,3)
    assert(expected==c.render())
  }

  it should "Draw a line vertically" in {
    val expected =
      """|---------------------
        ||      x             |
        ||      x             |
        ||      x             |
        ||                    |
        ||                    |
        |---------------------
        |""".stripMargin.replace("\r\n", "\n")
    val c = TextCanvas(5,20)
    c.drawLine(7,1,7,3)
    assert(expected==c.render())
  }
  it should "Draw a line vertically with reversed params" in {
    val expected =
      """|---------------------
         ||      x             |
         ||      x             |
         ||      x             |
         ||                    |
         ||                    |
         |---------------------
         |""".stripMargin.replace("\r\n", "\n")
    val c = TextCanvas(5,20)
    c.drawLine(7,3,7,1)
    assert(expected==c.render())
  }
  it should "Draw a diagonal line" in {
    val expected =
      """|---------------------
         ||    x               |
         ||   x                |
         ||  x                 |
         || x                  |
         ||x                   |
         |---------------------
         |""".stripMargin.replace("\r\n", "\n")
    val c = TextCanvas(5,20)
    c.drawLine(5,1,1,5)
    assert(expected==c.render())
  }

  it should "draw a rectangle" in {
    val expected =
      """---------------------
        ||                    |
        ||              xxxxxx|
        ||              x    x|
        ||              x    x|
        ||              xxxxxx|
        |---------------------
        |""".stripMargin.replace("\r\n", "\n")
    val c = TextCanvas(5,20)
    c.drawRect(15, 2, 20, 5)
    assert(expected==c.render())
  }

  it should "draw the shapes which match the spec" in {
    val expected =
      """---------------------
        ||      x             |
        ||      x       xxxxxx|
        ||xxxxxxx       x    x|
        ||              x    x|
        ||              xxxxxx|
        |---------------------
        |""".stripMargin.replace("\r\n", "\n")
    val c = TextCanvas(5,20)
    c.drawLine(1,3,7,3)
    c.drawLine(7,1,7,3)
    c.drawRect(20, 5, 15, 2)
    assert(expected==c.render())
  }
}
