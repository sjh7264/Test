import sbt._

object Dependencies {
  val ScalaTestVersion  = "3.0.0"
  val LogbackVersion = "1.2.3"


  val commonSettingsDependencies = Seq(
    "org.scalatest" %% "scalatest" % ScalaTestVersion % Test,
    "ch.qos.logback" % "logback-classic" % LogbackVersion
  )

  val dbpaintDependencies = Seq(
  )

}